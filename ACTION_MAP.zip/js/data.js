var data = [
  {
    "vname":"str1",
    "vtype":"string",
    "vdesc":"This is username",
  },
  {
    "vname":"str2",
    "vtype":"number",
    "vdesc":"This is username",
  },
  {
    "vname":"str3",
    "vtype":"object",
    "vdesc":"This is username",
    "keyVal":[
      {"vnam":"street","vtype":"string"},
      {"vnam":"pincode","vtype":"number"},
    ]
  },
]

var renderMeta = [
  {
    type:"div",
    class:"row",
    id:"",
    data:[{key:"mykey",value:"ok val"}],
    content:"",
    child:[
      {
        type:"div",
        class:"col-md-6 col-sm-6",
        id:"",
        data:[{key:"mykey",value:"ok val"}],
        content:"",
        child:[
          {
            type:"div",
            class:"",
            id:"m_mapper",
            data:[{key:"mykey",value:"ok val"}],
            content:"",
            child:[
              {
                type:"h5",
                class:"text-center",
                id:"",
                data:[],
                content:"Mapper",
                child:[
                ]
              }
            ]
          }
        ]
      },
      {
        type:"div",
        class:"col-md-6 col-sm-6",
        id:"",
        data:[{key:"mykey",value:"ok val"}],
        content:"",
        child:[
          {
            type:"div",
            class:"",
            id:"m_mapOpt",
            data:[],
            content:"",
            child:[
              {
                type:"h5",
                class:"text-center",
                id:"",
                data:[],
                content:"Mapper Option",
                child:[
                ]
              }
            ]
          }
        ]
      }  
    ]    
  },
]