console.warn("DATA", data);

// var map = new actionMapper("domDiv");
// map.map();


//args1: ParentNode args2: metaData -> array[{}]
let parentNode = document.getElementById("domDiv")
generateFromMeta(parentNode , renderMeta)