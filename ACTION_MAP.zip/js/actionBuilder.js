
class actionMapper{
  _mapperDiv = null;
  _optMapperDiv = null;
  constructor(pDivID){
    console.log("Action Mapper init: ", pDivID)
    this.parentDiv = document.getElementById(pDivID);
    this.buildDom()
  };
  map(){
    console.log("Mapping for Action")
  };
  buildDom(obj){
    console.log("Bulding dom on ", this.parentDiv);
    let ott = {type:"div",class:"row",id:"",data:[{key:"optn",value:"myval"}],content:""}
    let row = this.buildElement(this.parentDiv, ott);
    
  };

  //Bulding Data on JSON
  buildElement(pNode, obj){
    
    let nodeobj = document.createElement("div")
    if(obj.class && obj.class !== ""){
      nodeobj.setAttribute("class", obj.class)
    }
    if(obj.id && obj.id !== ""){
      nodeobj.setAttribute("id", obj.id)
    }
    // debugger
    if(obj.data.length > 0){
      let data = obj.data;
      for(let i in data){
        nodeobj.setAttribute("data-"+data[i].key, data[i].value);
      }  
    }
    pNode.appendChild(nodeobj)
    return nodeobj;
  }

}


function generateFromMeta(pNode, meta){
  console.log("Lenth:",meta.length, meta);
  for(let i in meta){
    let obj = meta[i];
    var nodeobj = document.createElement(obj.type)

    if(obj.class && obj.class !== ""){
      nodeobj.setAttribute("class", obj.class)
    }
    if(obj.id && obj.id !== ""){
      nodeobj.setAttribute("id", obj.id)
    }
    if(obj.content && obj.content !== ""){
      nodeobj.innerText= obj.content;
    }
    // debugger
    if(obj.data.length > 0){
      let data = obj.data;
      for(let i in data){
        nodeobj.setAttribute("data-"+data[i].key, data[i].value);
      }  
    }
    if(obj.child && obj.child.length > 0){
      generateFromMeta(nodeobj, obj.child)
    }

    pNode.appendChild(nodeobj)
  }
}

